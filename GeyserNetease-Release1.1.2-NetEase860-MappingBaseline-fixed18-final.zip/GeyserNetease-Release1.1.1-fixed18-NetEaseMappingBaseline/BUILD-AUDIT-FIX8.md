# GeyserNetease NetEase860 — fixed8 build audit

## 修复的编译根因

### 1. Cloudburst Protocol utility 包路径
`fixed7` 错误地把以下类从 `org.cloudburstmc.protocol.common.util` 改到了 `org.cloudburstmc.protocol.bedrock.util`：

- `TypeMap`
- `VarInts`
- `Preconditions`
- `SequencedHashSet`
- `Zlib`
- `IndexedList` (`common.util.index`)

本版本全部恢复为当前工程实际依赖使用的包路径。

### 2. PlayerAuthInputPacket API
`fixed7` 的 NetEase PlayerAuthInput serializers 调用了依赖版本 `PlayerAuthInputPacket` 中不存在的：

- `isCameraDeparted/setCameraDeparted`
- `isThirdPersonPerspective/setThirdPersonPerspective`
- `getPlayerRotationToCamera/setPlayerRotationToCamera`
- `isReadyPosDeltaDirty/setReadyPosDeltaDirty`
- `isOnGround/setOnGround`
- `getResetPosition/setResetPosition`

这些调用全部移除，恢复为该协议实现使用的固定兼容字段编码/解码方式，避免源码依赖不存在的 API。

## 保留的此前修复

- NetEase packet rewrite handler 位于 `BedrockPacketCodec` 之前。
- Packet trace 位于 `BedrockPacketCodec` 之后。
- NetEase 860 block-hash mapping 只有在三套 mapping 数据全部成功时才启用。
- StartGame 的 hash/checksum 修改逻辑保留。
- v819/v860 NetEase biome serializer 保留。
- NetEase 特殊 packet classes 保留。
- 不再自动注入空 `ConfirmSkinPacket`。

## 验证状态

本环境没有可用的 Gradle distribution/cache，因此无法在这里重新执行完整 `./gradlew compileJava`。

本次针对用户提供的 `build.log` 做了逐项根因修正，并进行了源码静态检查：

- 错误的 `bedrock.util.TypeMap/VarInts/Preconditions/SequencedHashSet/Zlib`：0
- 错误的 `bedrock.util.index.IndexedList`：0
- PlayerAuthInput 不存在 API 调用：0
- v819 biome serializer：存在
- v860 biome serializer：存在
- NetEaseJsonPacket / PyRpcPacket / StoreBuySuccessPacket / ConfirmSkinPacket：均存在

因此 fixed8 是针对该 `build.log` 的编译修正版，但不宣称已在本环境完成实际 Gradle 编译。
