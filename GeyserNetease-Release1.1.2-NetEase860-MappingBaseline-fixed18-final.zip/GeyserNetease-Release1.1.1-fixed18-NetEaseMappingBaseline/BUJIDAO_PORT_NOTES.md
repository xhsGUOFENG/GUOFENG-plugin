# GeyserNetease BuJiDao port notes

This source revision is based on the working diagnostic/API-migration source and ports the relevant architectural fixes from the public mc-dreamland/Geyser NetEase branch.

## Main changes

- NetEase codec helpers are created per connection instead of sharing one mutable helper instance.
- V819 no longer overrides the biome serializer with the old incompatible implementation.
- V860 NetEase biome serialization uses the current `Indexed` / `IndexedList` representation and the NetEase V860 wire layout used by mc-dreamland/Geyser.
- NetEase sessions keep the actual Bedrock protocol version for Geyser block/item mappings.
- The diagnostic `SpoofedUpstream` protocol-version wrapper is no longer injected. This avoids forcing newer/default protocol semantics onto a NetEase client.
- Resource-pack chunks use the normal upstream send path instead of always forcing immediate flushes.
- Resource-pack data type is no longer accidentally overwritten after pack type selection.
- NetEase resource-pack responses reuse the shared Geyser resource-pack state machine.
- The initializer binds each `GeyserSession` tick event loop to the connected Bedrock channel event loop, while keeping the official Geyser two-argument initializer constructor compatibility.
- Unsupported NetEase Bedrock protocol versions now disconnect explicitly instead of falling through to the normal Bedrock protocol path.
- Packet-trace diagnostics were removed from `SpoofedUpstream`.

## Build note

The working container does not have the required Gradle distribution/dependency cache and cannot download Gradle from the configured network. Therefore this archive has not been claimed as a successfully Gradle-built artifact here.

## PacketTrace-fixed2 changes

- Removed the `SpoofedUpstream` Unsafe wrapper from the live session path.
- Added `BlockMappingHashBridge`, which only prepares a per-session hashed mapping copy.
- Added `NetEasePacketTraceHandler` immediately after the Bedrock packet codec. It traces every IN/OUT BedrockPacketWrapper, encoded packet byte length, critical packet fields, last inbound/outbound packet, exceptions, and the final packet history.
- StartGame and UpdateBlock NetEase hash rewriting now happens in the packet pipeline without replacing `GeyserSession.upstream`.
- NetEase 860 packet header remains on the existing v3 codec path used by this source; no speculative protocol-header downgrade is included.


## fixed18 mapping baseline

Speculative runtime-hash rewriting and spawn-order gating were removed. NetEase now requests Geyser mappings by negotiated protocol first.
