# fixed18 — NetEase mapping baseline

This revision removes the speculative packet-layer interventions from fixed17:

- `NetEasePacketRewriteHandler`: removed; it forced `StartGame.blockNetworkIdsHashed=true` and rewrote `UpdateBlockPacket` runtime IDs to locally calculated FNV hashes.
- `NetEaseSpawnOrderHandler`: removed; the reference NetEase branch uses the normal Geyser startup flow and our trace already matched that order closely.
- `BlockMappingHashBridge`: removed from the live path; mutating Geyser's `BlockMappings` after registry construction is not equivalent to the reference dedicated NetEase palette architecture.

The login path now selects `BlockRegistries.BLOCKS.forVersion(netEaseProtocol)` first and only falls back to Geyser's default mapping if that protocol is absent. The official Bedrock codec is left untouched.

This is a clean baseline for the next real port: the dedicated NetEase block palette and `BlockRegistryPopulator`-style mapping construction still need to be embedded/ported.
