# NetEase 860 packet audit — current source state

## High-risk findings fixed

- NetEase packet rewrite was previously installed after `BedrockPacketCodec`; this was too late because the codec serializes `BedrockPacketWrapper` into `packetBuffer`. It is now installed before the codec.
- The packet trace remains after the codec so diagnostics see the encoded buffer.
- v819 NetEase biome serializer was referenced but absent; it is now present.
- Several NetEase protocol classes imported `TypeMap`/`VarInts`/related utilities from obsolete package locations; these now match the current Protocol API.
- v686/v766/v819 PlayerAuthInput helper read-side flag adaptation was inconsistent with the current NetEase reference implementation; corrected.
- v860 BiomeDefinitionList serializer now matches the current `BiomeDefinitionData` constructor shape and NetEase field order.
- Hash-mode mapping installation now fails closed: partial mapping patches are not exposed to a session.

## Protocol reference comparison

The NetEase codec registrations for v630/v686/v766/v819/v860, PyRpc, NetEaseJson, StoreBuySuccess and ConfirmSkin match the current Allay/Protocol reference structure. NetEase v860 also uses the v766 PlayerAuthInput serializer, v686 Text serializer, v407 NetEase enchant serializer, NetEase Biome serializer, and NetEase ContainerOpen serializer.

## Crash investigation relevance

The user's server trace shows a NetEase protocol-860 client reaching world initialization and then disappearing before normal gameplay packets. The server-side timeout is therefore treated as a consequence rather than the original cause.

The source audit prioritizes the packet boundary that can make the client interpret world block IDs incorrectly: StartGame's `blockNetworkIdsHashed` contract plus the actual Geyser block mappings used by chunk/update-block encoding. LevelChunk itself is inherited from the standard v860 codec; this extension does not locally replace its serializer.

CreativeContent, ItemComponent, AvailableEntityIdentifiers and CameraPresets are also inherited from the v860 base codec and were not locally reimplemented in this extension. They remain candidates for a second-stage isolation test if the client still crashes after the corrected hash/mapping path is tested.

## Build limitation

Gradle 9.2.0 could not be downloaded in the audit environment because `services.gradle.org` is unreachable. Java 21 is available. The source has therefore received structural/static checks, but not a dependency-resolved `compileJava` result.
