/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.session;

import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.geysermc.geyser.session.GeyserSession;

/**
 * Per-connection NetEase state.
 *
 * <p>Block runtime IDs deliberately are not transformed here. The NetEase
 * implementation must consume the BlockMappings selected by Geyser, exactly
 * as the reference NetEase implementation does. Any runtime-ID/hash transform
 * belongs to the mapping/codec layer, not to a per-session FNV table.</p>
 */
public class NeteaseSession {
    private final GeyserSession session;
    private final BedrockCodec codec;
    private final BedrockCodecHelper helper;
    private boolean loginDeferred;
    private boolean authenticated;
    private long uid;

    public NeteaseSession(GeyserSession session, int protocolVersion, BedrockCodec codec) {
        this.session = session;
        this.codec = codec;
        this.helper = codec.createHelper();
        this.uid = Math.abs(System.nanoTime());
    }

    public GeyserSession session() { return session; }
    public BedrockCodec codec() { return codec; }
    public BedrockCodecHelper helper() { return helper; }
    public boolean loginDeferred() { return loginDeferred; }
    public void setLoginDeferred(boolean v) { loginDeferred = v; }
    public boolean authenticated() { return authenticated; }
    public void setAuthenticated(boolean v) { authenticated = v; }
    public long uid() { return uid; }
    public void setUid(long v) { uid = v; }
}
