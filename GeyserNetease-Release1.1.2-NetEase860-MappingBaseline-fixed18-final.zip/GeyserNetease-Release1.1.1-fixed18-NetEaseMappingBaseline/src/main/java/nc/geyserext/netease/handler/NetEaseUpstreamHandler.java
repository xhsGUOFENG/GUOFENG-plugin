/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.handler;

import nc.geyserext.netease.NeteaseExtension;
import nc.geyserext.netease.session.NeteaseSession;
import nc.geyserext.netease.util.protocol.NeteaseCodecRegistry;
import org.cloudburstmc.math.vector.Vector3i;
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.data.PacketCompressionAlgorithm;
import org.cloudburstmc.protocol.bedrock.data.auth.CertificateChainPayload;
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryActionData;
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventorySource;
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType;
import org.cloudburstmc.protocol.bedrock.netty.codec.compression.*;
import org.cloudburstmc.protocol.bedrock.packet.*;
import org.cloudburstmc.protocol.bedrock.util.*;
import org.cloudburstmc.protocol.common.PacketSignal;
import org.geysermc.geyser.GeyserImpl;
import org.geysermc.geyser.api.event.bedrock.SessionInitializeEvent;
import org.geysermc.geyser.event.type.SessionLoadResourcePacksEventImpl;
import org.geysermc.geyser.registry.BlockRegistries;
import org.geysermc.geyser.registry.Registries;
import org.geysermc.geyser.network.bedrock.GameProtocol;
import org.geysermc.geyser.session.GeyserSession;
import org.geysermc.geyser.session.auth.*;
import org.geysermc.geyser.text.GeyserLocale;
import org.geysermc.mcprotocollib.protocol.data.game.entity.object.Direction;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.PlayerAction;
import org.geysermc.mcprotocollib.protocol.packet.ingame.serverbound.player.ServerboundPlayerActionPacket;

import javax.crypto.SecretKey;
import java.security.KeyPair;
import java.security.PublicKey;
import java.util.*;

public class NetEaseUpstreamHandler extends UpstreamHandlerBase {

    private NeteaseSession neteaseSession;

    public NetEaseUpstreamHandler(GeyserImpl geyser, GeyserSession session) {
        super(geyser, session);
    }

    @Override
    public PacketSignal handle(RequestNetworkSettingsPacket packet) {
        Integer rakVer = getRakVersion();
        boolean isNetEase = rakVer != null && rakVer == 8;
        if (!isNetEase) return super.handle(packet);

        BedrockCodec codec = NeteaseCodecRegistry.getCodec(packet.getProtocolVersion());
        if (codec == null) {
            session.disconnect("Unsupported NetEase Bedrock protocol: " + packet.getProtocolVersion());
            NeteaseExtension.LOG.warning("NetEase client used unsupported Bedrock protocol " + packet.getProtocolVersion());
            return PacketSignal.HANDLED;
        }

        NeteaseExtension.LOG.info("NetEase codec selected: protocol=" + packet.getProtocolVersion()
                + ", RakNet=" + rakVer);
        session.getUpstream().getSession().setCodec(codec);
        neteaseSession = new NeteaseSession(session, packet.getProtocolVersion(), codec);

        NetworkSettingsPacket resp = new NetworkSettingsPacket();
        resp.setCompressionAlgorithm(PacketCompressionAlgorithm.ZLIB);
        resp.setCompressionThreshold(512);
        session.sendUpstreamPacketImmediately(resp);

        NetEaseCompression nc = new NetEaseCompression();
        nc.setLevel(geyser.config().advanced().bedrock().compressionLevel());
        session.getUpstream().getSession().getPeer().setCompression(new SimpleCompressionStrategy(nc));

        networkSettingsRequested = true;
        return PacketSignal.HANDLED;
    }

    @Override
    public PacketSignal handle(LoginPacket packet) {
        if (neteaseSession == null) return super.handle(packet);
        if (!networkSettingsRequested) { session.disconnect("Protocol error"); return PacketSignal.HANDLED; }
        if (receivedLoginPacket) { session.disconnect("Duplicate login"); session.forciblyCloseUpstream(); return PacketSignal.HANDLED; }
        receivedLoginPacket = true;

        try {
            if (packet.getAuthPayload() instanceof CertificateChainPayload chain) {
                ChainValidationResult result = NetEaseEncryptionUtils.validateChain(chain);
                var extra = result.identityClaims().extraData;
                String name = extra.displayName != null ? extra.displayName : "NetEasePlayer";
                Long iat = (Long) result.rawIdentityClaims().get("iat");

                long neteaseUid = 0;
                Object red = result.rawIdentityClaims().get("extraData");
                if (red instanceof Map) {
                    Object u = ((Map<?, ?>) red).get("uid");
                    if (u instanceof Number) neteaseUid = ((Number) u).longValue();
                }
                if (neteaseUid == 0) neteaseUid = Math.abs(name.hashCode());
                neteaseSession.setUid(neteaseUid);

                String rawId = extra.identity != null ? extra.identity.toString() : null;
                UUID javaUuid = toStableUUID(rawId, neteaseUid);

                String xuid = String.valueOf(neteaseUid);

                session.setAuthData(new AuthData(name, javaUuid, xuid, iat != null ? iat : -1, extra.minecraftId != null ? extra.minecraftId : ""));
                session.setCertChainData(chain.getChain());

                if (packet.getClientJwt() != null && !packet.getClientJwt().isEmpty()) {
                    try {
                        byte[] cd = EncryptionUtils.verifyClientData(packet.getClientJwt(), result.identityClaims().parsedIdentityPublicKey());
                        if (cd != null) { BedrockClientData bcd = GeyserImpl.GSON.fromJson(new String(cd), BedrockClientData.class); bcd.setOriginalString(packet.getClientJwt()); session.setClientData(bcd); }
                    } catch (Exception ignored) {}
                }
                if (session.getClientData() == null)
                    session.setClientData(buildFakeClientData(name));

                startEncryptionHandshake(session, result.identityClaims().parsedIdentityPublicKey());
                if (session.isClosed()) { session.forciblyCloseUpstream(); return PacketSignal.HANDLED; }
                neteaseSession.setLoginDeferred(true);
            }
        } catch (Exception e) { session.disconnect("disconnectionScreen.internalError.cantConnect"); NeteaseExtension.LOG.error("NetEase auth failed", e); return PacketSignal.HANDLED; }

        // Use Geyser's actual mapping registry for the protocol negotiated by the
        // NetEase client. Do not synthesize hashed runtime IDs here: the reference
        // NetEase implementation builds its mappings from a dedicated Bedrock
        // palette at registry-population time, and the packet layer must consume
        // those definitions unchanged.
        final int netEaseProtocol = packet.getProtocolVersion();
        var blockMappings = BlockRegistries.BLOCKS.forVersion(netEaseProtocol);
        var itemMappings = Registries.ITEMS.forVersion(netEaseProtocol);

        // Some Geyser snapshots may not expose the negotiated protocol in their
        // registry table. Fall back to the current canonical mapping, never to a
        // synthesized hash table.
        if (blockMappings == null || itemMappings == null) {
            int fallbackProtocol = GameProtocol.DEFAULT_BEDROCK_PROTOCOL;
            blockMappings = BlockRegistries.BLOCKS.forVersion(fallbackProtocol);
            itemMappings = Registries.ITEMS.forVersion(fallbackProtocol);
            NeteaseExtension.LOG.warning("NetEase protocol " + netEaseProtocol
                    + " has no direct Geyser mapping; falling back to protocol " + fallbackProtocol);
        }

        if (blockMappings == null || itemMappings == null) {
            session.disconnect("Unable to initialize Geyser mappings for NetEase protocol " + netEaseProtocol);
            NeteaseExtension.LOG.error("Geyser mappings unavailable: netEaseProtocol=" + netEaseProtocol
                    + ", blockMappings=" + blockMappings + ", itemMappings=" + itemMappings);
            return PacketSignal.HANDLED;
        }

        session.setBlockMappings(blockMappings);
        session.setItemMappings(itemMappings);

        try {
            var channel = session.getUpstream().getSession().getPeer().getChannel();
            // Keep the official codec path untouched. NetEase-specific mapping
            // belongs in BlockMappings/palette, not a post-serialization patch.
            if (NeteaseExtension.CONFIG != null && NeteaseExtension.CONFIG.packetTrace()
                    && channel.pipeline().get(NetEasePacketTraceHandler.NAME) == null) {
                channel.pipeline().addBefore(org.cloudburstmc.protocol.bedrock.netty.codec.packet.BedrockPacketCodec.NAME,
                        NetEasePacketTraceHandler.NAME,
                        new NetEasePacketTraceHandler(session));
            }
            NeteaseExtension.LOG.info("NetEase mappings selected: netEaseProtocol=" + netEaseProtocol
                    + ", mappingProtocol=" + netEaseProtocol
                    + ", definitions=" + countDefinitions(blockMappings)
                    + ", hashedRuntimePatch=false"
                    + ", spawnReorder=false");
        } catch (Throwable e) {
            NeteaseExtension.LOG.error("NetEase packet trace install failed", e);
            session.disconnect("Unable to initialize NetEase packet diagnostics");
            return PacketSignal.HANDLED;
        }

        geyser.getSessionManager().addPendingSession(session);
        geyser.eventBus().fire(new SessionInitializeEvent(session));
        this.resourcePackLoadEvent = new SessionLoadResourcePacksEventImpl(session);
        this.geyser.eventBus().fireEventElseKick(this.resourcePackLoadEvent, session);
        if (session.isClosed()) return PacketSignal.HANDLED;
        session.integratedPackActive(resourcePackLoadEvent.isIntegratedPackActive());
        GeyserLocale.loadGeyserLocale(session.locale());
        return PacketSignal.HANDLED;
    }

    @Override
    public PacketSignal handle(PlayerAuthInputPacket packet) {
        return defaultHandler(packet);
    }

    @Override
    public PacketSignal handle(ClientToServerHandshakePacket packet) {
        if (neteaseSession != null && neteaseSession.loginDeferred()) {
            neteaseSession.setLoginDeferred(false);
            PlayStatusPacket ps = new PlayStatusPacket();
            ps.setStatus(PlayStatusPacket.Status.LOGIN_SUCCESS);
            session.sendUpstreamPacket(ps);
            if (this.resourcePackLoadEvent == null) {
                this.resourcePackLoadEvent = new SessionLoadResourcePacksEventImpl(session);
                this.geyser.eventBus().fireEventElseKick(this.resourcePackLoadEvent, session);
            }
            if (session.isClosed()) return PacketSignal.HANDLED;
            session.integratedPackActive(resourcePackLoadEvent.isIntegratedPackActive());
            ResourcePacksInfoPacket rpi = new ResourcePacksInfoPacket();
            rpi.getResourcePackInfos().addAll(this.resourcePackLoadEvent.infoPacketEntries());
            rpi.setVibrantVisualsForceDisabled(!session.isAllowVibrantVisuals());
            rpi.setForcedToAccept(geyser.config().gameplay().forceResourcePacks() || resourcePackLoadEvent.isIntegratedPackActive());
            rpi.setWorldTemplateId(new java.util.UUID(0L, 0L)); rpi.setWorldTemplateVersion("");
            session.sendUpstreamPacket(rpi);
            return PacketSignal.HANDLED;
        }
        return super.handle(packet);
    }

    @Override
    public PacketSignal handle(ResourcePackClientResponsePacket packet) {
        PacketSignal result = super.handle(packet);
        if (neteaseSession != null && packet.getStatus() == ResourcePackClientResponsePacket.Status.COMPLETED) {
            neteaseSession.setAuthenticated(true);
        }
        return result;
    }

    public PacketSignal handle(NetEaseJsonPacket p)  { return PacketSignal.HANDLED; }
    public PacketSignal handle(PyRpcPacket p)         { return PacketSignal.HANDLED; }
    public PacketSignal handle(StoreBuySuccessPacket p) { return PacketSignal.HANDLED; }
    public PacketSignal handle(ConfirmSkinPacket p)   { return PacketSignal.HANDLED; }

    public PacketSignal handle(InventoryTransactionPacket packet) {
        if (neteaseSession != null && packet.getTransactionType() == InventoryTransactionType.NORMAL
                && packet.getActions().size() == 2) {
            List<InventoryActionData> actions = packet.getActions();
            InventoryActionData action0 = actions.get(0);
            InventoryActionData action1 = actions.get(1);
            InventoryActionData worldAction = action0.getSource().getType() == InventorySource.Type.WORLD_INTERACTION ? action0 : action1;
            InventoryActionData containerAction = (worldAction == action0) ? action1 : action0;
            if (worldAction.getSource().getType() != InventorySource.Type.WORLD_INTERACTION
                    || containerAction.getSource().getType() != InventorySource.Type.CONTAINER)
                return defaultHandler(packet);

            boolean dropAll = worldAction.getToItem().getCount() > 1;
            var inventory = session.getPlayerInventory();
            if (inventory.getItemInHand().isEmpty()) return PacketSignal.HANDLED;

            session.sendDownstreamGamePacket(new ServerboundPlayerActionPacket(
                dropAll ? PlayerAction.DROP_ITEM_STACK : PlayerAction.DROP_ITEM, Vector3i.ZERO, Direction.DOWN, 0));

            if (dropAll) inventory.setItemInHand(org.geysermc.geyser.inventory.GeyserItemStack.EMPTY);
            else inventory.getItemInHand().sub(1);

            return PacketSignal.HANDLED;
        }
        return defaultHandler(packet);
    }

    private static int countDefinitions(org.geysermc.geyser.registry.type.BlockMappings mappings) {
        int count = 0;
        while (mappings.getDefinition(count) != null) count++;
        return count;
    }

    private static void startEncryptionHandshake(GeyserSession session, PublicKey clientKey) throws Exception {
        KeyPair serverKeyPair = EncryptionUtils.createKeyPair();
        byte[] token = EncryptionUtils.generateRandomToken();

        ServerToClientHandshakePacket handshake = new ServerToClientHandshakePacket();
        handshake.setJwt(EncryptionUtils.createHandshakeJwt(serverKeyPair, token));
        session.sendUpstreamPacketImmediately(handshake);

        SecretKey encryptionKey = EncryptionUtils.getSecretKey(serverKeyPair.getPrivate(), clientKey, token);
        session.getUpstream().getSession().enableEncryption(encryptionKey);
    }

    private Integer getRakVersion() {
        try { return session.getUpstream().getSession().getPeer().getChannel().config().getOption(RakChannelOption.RAK_PROTOCOL_VERSION); }
        catch (Exception e) { return null; }
    }
    private boolean couldLoginUserByName(String name) {
        if (geyser.config().savedUserLogins().contains(name)) {
            String chain = geyser.authChainFor(name);
            if (chain != null) { session.authenticateWithAuthChain(chain); return true; }
        }
        return false;
    }

    public NeteaseSession neteaseSession() { return neteaseSession; }

    private static BedrockClientData buildFakeClientData(String name) {
        return GeyserImpl.GSON.fromJson(
            "{\"GameVersion\":\"1.21.124\",\"LanguageCode\":\"en_us\",\"DeviceOS\":1," +
            "\"DeviceModel\":\"NetEase\",\"ThirdPartyName\":\"" + name + "\"," +
            "\"SkinId\":\"\",\"SkinData\":\"\",\"SkinImageWidth\":64,\"SkinImageHeight\":64," +
            "\"CapeId\":\"\",\"CapeData\":\"\",\"CapeImageWidth\":64,\"CapeImageHeight\":32," +
            "\"SkinGeometryData\":\"\",\"SkinResourcePatch\":\"\"," +
            "\"SkinGeometryDataEngineVersion\":\"\",\"PlayFabId\":\"\"," +
            "\"PersonaSkin\":false,\"PremiumSkin\":false,\"IsEditorMode\":false," +
            "\"SkinColor\":\"#0\",\"ArmSize\":\"wide\",\"PersonaPieces\":[],\"PieceTintColors\":[]}",
            BedrockClientData.class);
    }

    private static UUID toStableUUID(String rawIdentity, long neteaseUid) {
        if (rawIdentity != null && !rawIdentity.isEmpty()) {
            String hex = rawIdentity.replace("-", "");
            if (hex.length() == 32) {
                try {
                    return UUID.fromString(
                        hex.substring(0, 8) + "-" + hex.substring(8, 12) + "-" + hex.substring(12, 16) + "-"
                        + hex.substring(16, 20) + "-" + hex.substring(20));
                } catch (IllegalArgumentException ignored) {}
            }
        }
        String seed = "netease:player:" + neteaseUid;
        return UUID.nameUUIDFromBytes(seed.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
}
