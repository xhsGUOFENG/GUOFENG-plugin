package nc.geyserext.netease.handler;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import org.cloudburstmc.protocol.bedrock.packet.*;
import org.geysermc.geyser.session.GeyserSession;

import nc.geyserext.netease.NeteaseExtension;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * NetEase 860 diagnostic handler.
 *
 * Installed immediately after BedrockPacketCodec so outbound packetBuffer
 * contains the encoded bytes. This tracer intentionally avoids dumping large
 * packet objects and does not replay the entire packet history on disconnect.
 */
public final class NetEasePacketTraceHandler extends ChannelDuplexHandler {
    public static final String NAME = "netease-packet-trace";
    private static final int VALUE_LIMIT = 240;

    private final GeyserSession session;
    private final AtomicLong sequence = new AtomicLong();
    private final Map<String, Long> counts = new HashMap<>();
    private volatile String lastInbound = "none";
    private volatile String lastOutbound = "none";

    public NetEasePacketTraceHandler(GeyserSession session) {
        this.session = session;
    }

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
        if (msg instanceof BedrockPacket packet) {
            long n = sequence.incrementAndGet();
            String name = packet.getClass().getSimpleName();
            count(name);
            String line = describePacket("OUT", n, packet);
            lastOutbound = line;
            if (shouldLog(name, n)) log(line);
        } else if (msg instanceof ByteBuf buffer) {
            // If the tracer is placed before BedrockPacketCodec, outbound bytes
            // are not available here. Keep a compact byte-level breadcrumb for
            // pipelines/snapshots that invoke the handler with encoded data.
            lastOutbound = "bytes=" + buffer.readableBytes();
        }
        super.write(ctx, msg, promise);
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (msg instanceof BedrockPacket packet) {
            long n = sequence.incrementAndGet();
            String name = packet.getClass().getSimpleName();
            count(name);
            String line = describePacket("IN", n, packet);
            lastInbound = line;
            log(line);
        } else if (msg instanceof ByteBuf buffer) {
            lastInbound = "bytes=" + buffer.readableBytes();
        }
        super.channelRead(ctx, msg);
    }

    private String describePacket(String direction, long n, BedrockPacket packet) {
        StringBuilder sb = new StringBuilder(320);
        sb.append("[NetEase-PacketTrace] ").append(direction)
                .append(" #").append(n)
                .append(" player=").append(player())
                .append(" protocol=").append(session.protocolVersion())
                .append(" packet=").append(packet.getClass().getSimpleName());
        String critical = criticalFields(packet);
        if (!critical.isEmpty()) sb.append(" fields=").append(critical);
        return sb.toString();
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        dumpSummary("channelInactive");
        super.channelInactive(ctx);
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        log("[NetEase-PacketTrace] EXCEPTION player=" + player()
                + " type=" + cause.getClass().getName()
                + " message=" + String.valueOf(cause.getMessage())
                + " lastIN=" + lastInbound
                + " lastOUT=" + lastOutbound);
        dumpSummary("exceptionCaught");
        super.exceptionCaught(ctx, cause);
    }

    private String criticalFields(BedrockPacket packet) {
        String name = packet.getClass().getSimpleName();
        if (!isCritical(name)) return "";

        String[] getters = switch (name) {
            case "StartGamePacket" -> new String[]{
                    "getDimensionId", "isBlockNetworkIdsHashed", "getBlockRegistryChecksum", "getBlockPalette"};
            case "LevelChunkPacket" -> new String[]{
                    "getChunkX", "getChunkZ", "getSubChunksLength", "getData", "getSubChunks"};
            case "BiomeDefinitionListPacket" -> new String[]{"getDefinitions", "getBiomes"};
            case "ItemComponentPacket" -> new String[]{"getEntries", "getComponents"};
            case "AvailableEntityIdentifiersPacket" -> new String[]{"getIdentifiers", "getNbt"};
            case "CameraPresetsPacket" -> new String[]{"getPresets"};
            case "CreativeContentPacket" -> new String[]{"getContents"};
            case "ResourcePacksInfoPacket" -> new String[]{
                    "getResourcePackInfos", "isForcedToAccept", "getWorldTemplateId", "getWorldTemplateVersion"};
            case "PlayStatusPacket" -> new String[]{"getStatus"};
            default -> new String[0];
        };

        StringBuilder out = new StringBuilder(240);
        for (String getter : getters) {
            try {
                Method method = packet.getClass().getMethod(getter);
                Object value = method.invoke(packet);
                String text = summarize(getter, value);
                if (!out.isEmpty()) out.append(',');
                out.append(getter).append('=').append(text);
            } catch (Throwable ignored) {
                // Version-specific fields are intentionally optional.
            }
        }
        return out.toString();
    }

    private boolean isCritical(String name) {
        return switch (name) {
            case "StartGamePacket", "ItemComponentPacket", "LevelChunkPacket",
                 "BiomeDefinitionListPacket", "AvailableEntityIdentifiersPacket",
                 "CameraPresetsPacket", "CreativeContentPacket",
                 "ResourcePacksInfoPacket", "ResourcePackDataInfoPacket",
                 "ResourcePackChunkDataPacket", "ResourcePackStackPacket",
                 "PlayStatusPacket" -> true;
            default -> false;
        };
    }

    private boolean shouldLog(String packetName, long sequenceNumber) {
        // NetworkStackLatencyPacket is a heartbeat-like packet and was flooding
        // the old trace once per second. Count it for the final summary instead.
        return !"NetworkStackLatencyPacket".equals(packetName);
    }

    private String summarize(String getter, Object value) {
        if (value == null) return "null";
        if (value instanceof ByteBuf b) return "ByteBuf[readable=" + b.readableBytes() + "]";
        if (value instanceof Collection<?> c) return "Collection[size=" + c.size() + "]";
        if (value.getClass().isArray()) return "Array[len=" + Array.getLength(value) + "]";

        // Block palette is intentionally summarized rather than stringified;
        // the old tracer could dump a massive object here.
        if ("getBlockPalette".equals(getter)) {
            return "present=" + (value != null);
        }

        String s = String.valueOf(value).replace('\n', ' ');
        if (s.length() > VALUE_LIMIT) {
            s = s.substring(0, VALUE_LIMIT) + "...";
        }
        return s;
    }

    private void count(String packetName) {
        synchronized (counts) {
            counts.merge(packetName, 1L, Long::sum);
        }
    }

    private void log(String line) {
        if (NeteaseExtension.LOG != null) NeteaseExtension.LOG.info(line);
    }

    private String player() {
        try {
            String name = session.bedrockUsername();
            return name == null || name.isEmpty() ? "unknown" : name;
        } catch (Throwable ignored) {
            return "unknown";
        }
    }

    private void dumpSummary(String reason) {
        if (NeteaseExtension.LOG == null) return;

        StringBuilder sb = new StringBuilder();
        synchronized (counts) {
            for (Map.Entry<String, Long> entry : counts.entrySet()) {
                if (!sb.isEmpty()) sb.append(", ");
                sb.append(entry.getKey()).append('x').append(entry.getValue());
            }
        }

        NeteaseExtension.LOG.info("[NetEase-PacketTrace] SUMMARY reason=" + reason
                + " player=" + player()
                + " total=" + sequence.get()
                + " lastIN=" + lastInbound
                + " lastOUT=" + lastOutbound
                + " counts=" + sb);
    }
}
