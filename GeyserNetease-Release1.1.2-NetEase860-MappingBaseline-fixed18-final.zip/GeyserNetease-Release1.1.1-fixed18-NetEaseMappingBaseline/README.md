# GeyserNetease 扩展

## 这是什么？

GeyserNetease 是一个 **Geyser 扩展**，它能让 **网易版 Minecraft（中国版基岩版）** 的玩家连接到使用 Geyser 的服务器。

简单来说：如果你有一个 Java 版 Minecraft 服务器，并且用 Geyser 让基岩版玩家也能进来玩，那么装了这个扩展之后，**网易版的玩家也能加入你的服务器了**。

---

## 为什么需要它？

网易版 Minecraft 虽然也是基岩版，但它和国际版基岩版有一些区别：
- 使用不同的网络协议版本
- 有自己的账号验证系统
- 包含一些网易特有的游戏内容

默认的 Geyser 只能连接国际版基岩版玩家，网易版玩家是进不来的。装了这个扩展之后，你的服务器就能同时支持：
- ✅ Java 版玩家
- ✅ 国际版基岩版玩家
- ✅ **网易版基岩版玩家**（本扩展新增）

---

## 下载前你需要知道的

### 前置要求
1. 你必须已经安装了 **Geyser**（这是 Geyser 的扩展，不能单独使用）
2. 你的 Geyser 版本需要支持扩展 API 2.9.10 或更高

### 配置说明
安装后，扩展会生成一个配置文件 `config.yml`，里面有几个重要选项：

#### 1. 只允许网易客户端 (`only-netease-clients`)
- `false`（默认）：国际版和网易版都能进
- `true`：只允许网易版玩家进入，国际版玩家会被拒绝

#### 2. 调试模式 (`debug-mode`)
- `false`（默认）：正常运行，日志较少
- `true`：输出详细日志，遇到连接问题时可以打开排查

### 支持的版本
支持多个网易版协议版本，包括 v630、v686、v766、v819 等。

---

## 常见问题

**Q：装了这个会影响国际版玩家吗？**
A：不会。默认配置下，国际版和网易版玩家都能正常游玩，互不影响。

**Q：网易玩家进来后能玩所有内容吗？**
A：大部分内容都可以正常玩。但网易版特有的一些内容（比如特定皮肤、商城物品）可能无法完全兼容。

**Q：这个扩展是官方的吗？**
A：不是。这是社区开发者制作的第三方扩展。

---

## 作者
EiluDick / ZDarkZ


## fixed17

- Restored NetEase `RECIPE_BOOK` container slot mapping for v819/v860.
- Restored the NetEase v819 biome serializer registration.
- Keeps the v860 NetEase spawn-order and packet-rewrite fixes from fixed13.
