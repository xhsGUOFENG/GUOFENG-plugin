# NetEase 860 packet compatibility audit

This revision is a source-audited follow-up to fixed6. It fixes source/API mistakes found during the audit before the project is handed back for testing.

## Corrected in this audit

1. **Packet rewrite pipeline position**
   - `BedrockPacketCodec` is a `MessageToMessageCodec<ByteBuf, BedrockPacketWrapper>` and encodes the packet into `packetBuffer` before forwarding it downstream.
   - Therefore NetEase protocol rewrites must run **before** `BedrockPacketCodec`.
   - `NetEasePacketRewriteHandler` is now installed before the codec.
   - `NetEasePacketTraceHandler` remains after the codec so its `packetBuffer` represents the encoded packet.

2. **StartGame hashed block-network-ID contract**
   - When the per-session Geyser block mappings are successfully patched to NetEase FNV-1a state hashes, the rewrite sets `blockNetworkIdsHashed=true` and `blockRegistryChecksum=0` before encoding.
   - If mapping patching is incomplete, the extension keeps the original Geyser mappings and does not advertise hash mode.

3. **Block mapping patch safety**
   - Hash mode now requires all three runtime mapping arrays used by Geyser (`javaToBedrockBlocks`, `bedrockRuntimeMap`, `javaToVanillaBedrockBlocks`) to be patched.
   - A partially patched clone is never installed on the session.

4. **Current Protocol package/API imports**
   - NetEase codec/helper/serializer classes now use the current `org.cloudburstmc.protocol.bedrock.util.*` locations for `TypeMap`, `VarInts`, `Preconditions`, `SequencedHashSet`, `IndexedList`, and `Zlib`.

5. **v819 NetEase biome serializer**
   - Restored the missing `BiomeDefinitionListSerializer_v819_NetEase` source referenced by `Bedrock_v819_NetEase`.

6. **v860 BiomeDefinitionList serializer**
   - Updated to the current NetEase v860 `BiomeDefinitionData` constructor and current IndexedList API.

7. **PlayerAuthInput helpers**
   - NetEase read-side flag ordinal adaptation now removes the NetEase-only gap; write-side adaptation still shifts later flags upward.

## Previously fixed and retained

- Empty automatic `ConfirmSkinPacket` injection after StartGame is removed.
- NetEase `ContainerOpen` trailing `ignoreBlock` field is read/written correctly.
- NetEase `RECIPE_CUSTOM` container slot mapping is retained.
- v630/v686/v766 PlayerAuthInput serializers use packet values instead of hardcoded placeholders.

## Verification limitation

A full Gradle build was attempted with Java 21, but the wrapper distribution is not cached and the environment cannot resolve `services.gradle.org`. Therefore dependency-level compilation must still be run in an environment with the Gradle 9.2.0 distribution and the configured Maven repositories available.


## fixed10 build-log corrections
- Aligned BiomeDefinitionData construction with the current Protocol 3.0 Beta13 API: v819 uses the public Indexable constructor without a foliageSnow placeholder; v860 converts the IndexedList to the public List-based constructor.
- Removed the obsolete ContainerSlotType.RECIPE_CUSTOM reference. Current Protocol does not define that enum; NetEase slot 17 is retained as UNKNOWN rather than inventing an enum constant.
- Removed all record-style BiomeDefinitionData accessors from the NetEase serializers.
