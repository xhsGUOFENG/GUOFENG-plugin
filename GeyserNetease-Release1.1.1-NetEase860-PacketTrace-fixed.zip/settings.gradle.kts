rootProject.name = "GeyserNetEaseExtension"
