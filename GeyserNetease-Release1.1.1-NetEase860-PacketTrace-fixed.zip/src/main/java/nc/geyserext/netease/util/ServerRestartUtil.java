package nc.geyserext.netease.util;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.*;
import io.netty.channel.socket.DatagramPacket;
import io.netty.util.NettyRuntime;
import io.netty.util.concurrent.DefaultThreadFactory;
import io.netty.util.internal.SystemPropertyUtil;
import nc.geyserext.netease.initializer.NeteaseServerInitializer;
import org.checkerframework.checker.nullness.qual.NonNull;
import org.cloudburstmc.netty.channel.raknet.RakChannelFactory;
import org.cloudburstmc.netty.channel.raknet.RakServerChannel;
import org.cloudburstmc.netty.channel.raknet.config.*;
import org.cloudburstmc.netty.handler.codec.raknet.server.RakServerOfflineHandler;
import org.geysermc.geyser.GeyserImpl;
import org.geysermc.geyser.configuration.GeyserConfig;
import org.geysermc.geyser.network.BedrockPingHandler;
import org.geysermc.geyser.network.ConnectionRequests;
import org.geysermc.geyser.network.RaknetServer;
import org.geysermc.geyser.network.bedrock.raknet.RakPingHandler;
import org.geysermc.mcprotocollib.network.helper.TransportHelper;

import java.lang.reflect.Field;
import java.net.InetSocketAddress;

import static org.cloudburstmc.netty.channel.raknet.RakConstants.*;

public final class ServerRestartUtil {
    private static final TransportHelper.TransportType TRANSPORT = TransportHelper.TRANSPORT_TYPE;
    private ServerRestartUtil() {}

    public static void restart(boolean onlyNeteaseClients) {
        try {
            doRestart(onlyNeteaseClients);
        } catch (NoClassDefFoundError e) {
            GeyserImpl.getInstance().getLogger().info("[GeyserNetease] Mod platform detected; skipping server restart. NetEase support active through channel hook.");
        } catch (Exception e) {
            GeyserImpl.getInstance().getLogger().error("[GeyserNetease] Failed to restart bedrock listener", e);
        }
    }

    private static void doRestart(boolean onlyNeteaseClients) throws Exception {
        GeyserImpl geyser = GeyserImpl.getInstance();
        RaknetServer server = geyser.getGeyserServer();
        server.shutdown();

        Integer bt = Integer.getInteger("Geyser.BedrockNetworkThreads");
        if (bt == null) {
            bt = Math.max(1, SystemPropertyUtil.getInt("io.netty.eventLoopThreads", NettyRuntime.availableProcessors() * 2));
        }

        int listenCount = BootstrapsCompat.isReusePortAvailable()
            ? Integer.getInteger("Geyser.ListenCount", 1) : 1;
        EventLoopGroup g = TRANSPORT.eventLoopGroupFactory().apply(listenCount, new DefaultThreadFactory("GeyserServer", true));
        EventLoopGroup cg = TRANSPORT.eventLoopGroupFactory().apply(bt, new DefaultThreadFactory("GeyserServerChild", true));

        GeyserConfig cfg = geyser.config();
        boolean rakCookie = Boolean.parseBoolean(System.getProperty("Geyser.RakSendCookie", "true"));
        NeteaseServerInitializer init = new NeteaseServerInitializer(geyser, rakCookie, onlyNeteaseClients);

        ServerBootstrap bs = new ServerBootstrap()
            .channelFactory(RakChannelFactory.server(TRANSPORT.datagramChannelClass()))
            .group(g, cg)
            .option(RakChannelOption.RAK_HANDLE_PING, true)
            .option(RakChannelOption.RAK_MAX_MTU, cfg.advanced().bedrock().mtu())
            .option(RakChannelOption.RAK_PACKET_LIMIT, positiveProp("Geyser.RakPacketLimit", DEFAULT_PACKET_LIMIT))
            .option(RakChannelOption.RAK_GLOBAL_PACKET_LIMIT, positiveProp("Geyser.RakGlobalPacketLimit", DEFAULT_GLOBAL_PACKET_LIMIT))
            .option(RakChannelOption.RAK_SERVER_COOKIE_MODE, rakCookie ? RakServerCookieMode.ACTIVE : RakServerCookieMode.INVALID)
            .option(RakChannelOption.RAK_PROXY_PROTOCOL, cfg.advanced().bedrock().useHaproxyProtocol())
            .childHandler(init);
        BootstrapsCompat.setupBootstrap(bs);

        ChannelFuture[] futures = new ChannelFuture[listenCount];
        BedrockPingHandler pingResponder = new BedrockPingHandler(geyser);
        for (int i = 0; i < listenCount; i++) {
            ChannelFuture fut = bs.bind(new InetSocketAddress(cfg.bedrock().address(), cfg.bedrock().port()));
            fut.addListener((ChannelFutureListener) f -> {
                if (!f.isSuccess()) return;
                Channel c = f.channel();
                c.pipeline()
                    .addBefore(RakServerOfflineHandler.NAME, ConnectionGate.NAME, new ConnectionGate(geyser))
                    .addAfter(RakServerOfflineHandler.NAME, RakPingHandler.NAME, new RakPingHandler(pingResponder));
            });
            futures[i] = fut;
        }
        BootstrapsCompat.allOf(futures).join();

        setField(RaknetServer.class, "group", server, g);
        setField(RaknetServer.class, "childGroup", server, cg);
        setField(RaknetServer.class, "playerGroup", server, init.playerEventLoopGroup());
        setField(RaknetServer.class, "bootstrapFutures", server, futures);
        setField(RaknetServer.class, "listenCount", server, listenCount);
    }

    private static void setField(Class<?> c, String n, Object target, Object value) throws Exception {
        Field f = c.getDeclaredField(n);
        f.setAccessible(true);
        f.set(target, value);
    }

    private static int positiveProp(String p, int d) {
        String v = System.getProperty(p);
        try {
            int x = v != null ? Integer.parseInt(v) : d;
            return Math.max(x, 1);
        } catch (NumberFormatException e) {
            return d;
        }
    }

    private static final class ConnectionGate extends ChannelInboundHandlerAdapter {
        static final String NAME = "geyser-netease-connection-gate";
        private final GeyserImpl geyser;
        ConnectionGate(GeyserImpl geyser) { this.geyser = geyser; }

        @Override
        public void channelRead(@NonNull ChannelHandlerContext ctx, @NonNull Object msg) {
            if (!(msg instanceof DatagramPacket packet)) {
                ctx.fireChannelRead(msg);
                return;
            }
            ByteBuf buf = packet.content();
            if (!buf.isReadable()) { buf.release(); return; }
            int start = buf.readerIndex();
            boolean readableMagic = false;
            try {
                int id = buf.readUnsignedByte();
                if (id == ID_OPEN_CONNECTION_REQUEST_1) {
                    ByteBuf magic = ctx.channel().config().getOption(RakChannelOption.RAK_UNCONNECTED_MAGIC);
                    readableMagic = buf.isReadable(magic.readableBytes()) && ByteBufUtil.equals(buf.readSlice(magic.readableBytes()), magic);
                }
            } finally { buf.readerIndex(start); }
            if (!readableMagic) { ctx.fireChannelRead(msg); return; }

            InetSocketAddress address = packet.sender();
            InetSocketAddress clientAddress = ((RakServerChannel) ctx.channel()).getClientAddress(address);
            if (!ConnectionRequests.accept(geyser, clientAddress, null)) {
                ByteBuf magic = ctx.channel().config().getOption(RakChannelOption.RAK_UNCONNECTED_MAGIC);
                long guid = ctx.channel().config().getOption(RakChannelOption.RAK_GUID);
                ByteBuf out = ctx.alloc().ioBuffer(25, 25);
                out.writeByte(ID_CONNECTION_BANNED);
                out.writeBytes(magic, magic.readerIndex(), magic.readableBytes());
                out.writeLong(guid);
                ctx.writeAndFlush(new DatagramPacket(out, address));
            } else {
                ctx.fireChannelRead(msg);
            }
        }
    }

    private static final class BootstrapsCompat {
        static boolean isReusePortAvailable() {
            try {
                Class<?> c = Class.forName("org.geysermc.geyser.network.bedrock.raknet.Bootstraps");
                return (boolean) c.getMethod("isReusePortAvailable").invoke(null);
            } catch (Throwable t) { return false; }
        }
        static boolean setupBootstrap(ServerBootstrap bs) {
            try {
                Class<?> c = Class.forName("org.geysermc.geyser.network.bedrock.raknet.Bootstraps");
                return (boolean) c.getMethod("setupBootstrap", ServerBootstrap.class, TransportHelper.TransportType.class).invoke(null, bs, TRANSPORT);
            } catch (Throwable t) { return false; }
        }
        static java.util.concurrent.CompletableFuture<Void> allOf(ChannelFuture[] fs) {
            try {
                Class<?> c = Class.forName("org.geysermc.geyser.network.bedrock.raknet.Bootstraps");
                @SuppressWarnings("unchecked") java.util.concurrent.CompletableFuture<Void> f =
                    (java.util.concurrent.CompletableFuture<Void>) c.getMethod("allOf", ChannelFuture[].class).invoke(null, (Object) fs);
                return f;
            } catch (Throwable t) {
                java.util.concurrent.CompletableFuture<Void> f = new java.util.concurrent.CompletableFuture<>();
                for (ChannelFuture x : fs) x.addListener((ChannelFutureListener) y -> { if (!y.isSuccess()) f.completeExceptionally(y.cause()); });
                if (java.util.Arrays.stream(fs).allMatch(ChannelFuture::isSuccess)) f.complete(null);
                return f;
            }
        }
    }
}
