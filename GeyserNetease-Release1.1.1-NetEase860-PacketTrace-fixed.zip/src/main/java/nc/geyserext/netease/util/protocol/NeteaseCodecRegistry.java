/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.util.protocol;

import org.cloudburstmc.protocol.bedrock.codec.BedrockCodec;
import org.cloudburstmc.protocol.bedrock.codec.BedrockCodecHelper;
import org.cloudburstmc.protocol.bedrock.codec.v630_netease.Bedrock_v630_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v686_netease.Bedrock_v686_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v766_netease.Bedrock_v766_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v819_netease.Bedrock_v819_NetEase;
import org.cloudburstmc.protocol.bedrock.codec.v860_netease.Bedrock_v860_NetEase;
import org.cloudburstmc.protocol.bedrock.data.EncodingSettings;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/**
 * NetEase Bedrock codecs.
 *
 * A codec helper contains per-connection mutable state (block definitions, caches,
 * string tables, etc.), so it must never be shared between sessions.
 */
public final class NeteaseCodecRegistry {

    private static final EncodingSettings NETEASE_ENCODING_SETTINGS = EncodingSettings.builder()
        .maxListSize(Integer.MAX_VALUE)
        .maxByteArraySize(Integer.MAX_VALUE)
        .maxNetworkNBTSize(Integer.MAX_VALUE)
        .maxItemNBTSize(Integer.MAX_VALUE)
        .maxStringLength(Integer.MAX_VALUE)
        .build();

    private static final Map<Integer, BedrockCodec> CODECS = new ConcurrentHashMap<>();

    static {
        register(Bedrock_v630_NetEase.CODEC);
        register(Bedrock_v686_NetEase.CODEC);
        register(Bedrock_v766_NetEase.CODEC);
        register(Bedrock_v819_NetEase.CODEC);
        register(Bedrock_v860_NetEase.CODEC);
    }

    private static void register(BedrockCodec codec) {
        // Capture the original codec rather than a single helper instance.
        Supplier<BedrockCodecHelper> helperFactory = () -> {
            BedrockCodecHelper helper = codec.createHelper();
            helper.setEncodingSettings(NETEASE_ENCODING_SETTINGS);
            return helper;
        };
        CODECS.put(codec.getProtocolVersion(), codec.toBuilder().helper(helperFactory).build());
    }

    public static BedrockCodec getCodec(int version) {
        return CODECS.get(version);
    }

    private NeteaseCodecRegistry() {
    }
}
