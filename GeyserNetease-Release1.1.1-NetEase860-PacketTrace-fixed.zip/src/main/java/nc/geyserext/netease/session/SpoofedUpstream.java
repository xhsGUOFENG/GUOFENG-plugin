/*
 * Copyright (c) 2026 EiluDick/ZDarkZ
 * Released under the MIT License.
 */

package nc.geyserext.netease.session;

import nc.geyserext.netease.util.BlockHashUtils;
import org.cloudburstmc.nbt.NbtMap;
import nc.geyserext.netease.NeteaseExtension;
import org.cloudburstmc.protocol.bedrock.BedrockServerSession;
import org.cloudburstmc.protocol.bedrock.data.definitions.BlockDefinition;
import org.cloudburstmc.protocol.bedrock.data.skin.SerializedSkin;
import org.cloudburstmc.protocol.bedrock.packet.*;
import org.geysermc.geyser.network.bedrock.GameProtocol;
import org.geysermc.geyser.registry.type.BlockMappings;
import org.geysermc.geyser.registry.type.GeyserBedrockBlock;
import org.geysermc.geyser.session.UpstreamSession;
import sun.misc.Unsafe;
import java.lang.reflect.Field;
import java.util.*;

public class SpoofedUpstream extends UpstreamSession {

    private final UpstreamSession real;
    private final int spoofedVersion;
    private final int[] rtToHash;
    private final boolean[] hValid;
    private final boolean hashing;
    private final long neteaseUid;
    private boolean skinConfirmed;
    private long packetTraceIndex;

    public SpoofedUpstream(UpstreamSession real, BedrockServerSession s,
            int[] rt, boolean[] hv, boolean hashing, long neteaseUid) {
        super(s);
        this.real = real;
        this.spoofedVersion = GameProtocol.DEFAULT_BEDROCK_PROTOCOL;
        this.rtToHash = rt;
        this.hValid = hv;
        this.hashing = hashing;
        this.neteaseUid = neteaseUid;
    }

    @Override public void disconnect(String r) { real.disconnect(r); }
    @Override public int getProtocolVersion() { return spoofedVersion; }
    @Override public BedrockServerSession getSession() { return real.getSession(); }
    @Override public boolean isClosed() { return real.isClosed(); }
    @Override public void sendPacket(BedrockPacket p) {
        traceOutbound(p, false);
        real.sendPacket(rewrite(p));
        hook(p, false);
    }

    @Override public void sendPacketImmediately(BedrockPacket p) {
        traceOutbound(p, true);
        real.sendPacketImmediately(rewrite(p));
        hook(p, true);
    }

    private void traceOutbound(BedrockPacket packet, boolean immediate) {
        if (packet == null) return;
        long index = ++packetTraceIndex;
        String simple = packet.getClass().getSimpleName();
        String full = packet.getClass().getName();
        String player = "unknown";
        NeteaseExtension.LOG.info("[NetEase-PacketTrace] OUT #" + index
                + " player=" + player
                + " packet=" + simple
                + " class=" + full
                + " immediate=" + immediate);
    }

    private BedrockPacket rewrite(BedrockPacket p) {
        if (!hashing) return p;
        if (p instanceof UpdateBlockPacket ub) ub.setDefinition(wrapDef(ub.getDefinition()));
        else if (p instanceof StartGamePacket sg) rewriteStartGame(sg);
        return p;
    }

    private void hook(BedrockPacket p, boolean immediate) {
        if (!hashing) return;
        if (p instanceof StartGamePacket && !skinConfirmed) {
            skinConfirmed = true;
            ConfirmSkinPacket csp = new ConfirmSkinPacket();
            ConfirmSkinPacket.SkinEntry e = new ConfirmSkinPacket.SkinEntry();
            e.setValid(true);
            e.setUidStr(String.valueOf(neteaseUid));
            csp.getEntries().add(e);
            if (immediate) real.sendPacketImmediately(csp); else real.sendPacket(csp);
        } else if (p instanceof PlayerSkinPacket ps && ps.getSkin() != null) {
            sendSkinCsp(ps.getUuid(), ps.getSkin(), immediate);
        } else if (p instanceof PlayerListPacket pl && pl.getAction() == PlayerListPacket.Action.ADD) {
            for (PlayerListPacket.Entry entry : pl.getEntries()) {
                if (entry.getSkin() != null && entry.getSkin().getSkinData().getImage().length > 0) {
                    sendSkinCsp(entry.getUuid(), entry.getSkin(), immediate);
                }
            }
        }
    }

    private void sendSkinCsp(UUID uuid, SerializedSkin skin, boolean immediate) {
        ConfirmSkinPacket csp = new ConfirmSkinPacket();
        ConfirmSkinPacket.SkinEntry e = new ConfirmSkinPacket.SkinEntry();
        e.setValid(true);
        e.setUuid(uuid);
        e.setSkinBytes(skin.getSkinData().getImage());
        e.setGeoStr(skin.getGeometryData());
        e.setUidStr(String.valueOf(Math.abs(uuid.toString().replace("-", "").hashCode())));
        csp.getEntries().add(e);
        if (immediate) real.sendPacketImmediately(csp); else real.sendPacket(csp);
    }

    private void rewriteStartGame(StartGamePacket sg) {
        sg.setBlockNetworkIdsHashed(true);
        sg.setBlockRegistryChecksum(0L);
        List<NbtMap> pal = sg.getBlockPalette();
        if (pal == null || pal.isEmpty()) return;
        TreeMap<Integer, NbtMap> sorted = new TreeMap<>();
        int idx = 0;
        for (NbtMap e : pal) {
            if (idx < hValid.length && hValid[idx]) sorted.put(rtToHash[idx], e);
            else if (idx < rtToHash.length) sorted.put(idx, e);
            idx++;
        }
        pal.clear();
        sorted.values().forEach(pal::add);
    }

    private BlockDefinition wrapDef(BlockDefinition def) {
        if (def == null) return null;
        int id = def.getRuntimeId();
        if (id >= 0 && id < hValid.length && hValid[id]) {
            int h = rtToHash[id];
            return new BlockDefinition() { public int getRuntimeId() { return h; } };
        }
        return def;
    }

    private static final Unsafe U;
    static {
        try {
            Field f = Unsafe.class.getDeclaredField("theUnsafe");
            f.setAccessible(true);
            U = (Unsafe) f.get(null);
        } catch (Throwable e) { throw new ExceptionInInitializerError(e); }
    }

    public static int definitionCount(BlockMappings orig) throws Throwable {
        Field f = BlockMappings.class.getDeclaredField("bedrockRuntimeMap");
        f.setAccessible(true);
        long off = U.objectFieldOffset(f);
        Object value = U.getObject(orig, off);
        return value instanceof GeyserBedrockBlock[] array ? array.length : 0;
    }

    public static boolean patchAll(BlockMappings orig) throws Throwable {
        boolean ok = patchOne(orig, "javaToBedrockBlocks");
        ok |= patchOne(orig, "bedrockRuntimeMap");
        ok |= patchOne(orig, "javaToVanillaBedrockBlocks");
        patchSingletonBlockDef(orig, "bedrockAir");
        patchSingletonBlockDef(orig, "bedrockWater");
        patchSingletonBlockDef(orig, "bedrockMovingBlock");
        return ok;
    }

    private static void patchSingletonBlockDef(BlockMappings orig, String fieldName) {
        try {
            Field f = BlockMappings.class.getDeclaredField(fieldName);
            long offset = U.objectFieldOffset(f);
            Object old = U.getObject(orig, offset);
            if (old instanceof GeyserBedrockBlock gb && gb.getState() != null) {
                U.putObject(orig, offset, new GeyserBedrockBlock(BlockHashUtils.fnv1a32Nbt(gb.getState()), gb.getState()));
            }
        } catch (Throwable ignored) {}
    }

    private static boolean patchOne(BlockMappings orig, String fieldName) {
        try {
            Field f = BlockMappings.class.getDeclaredField(fieldName);
            long offset = U.objectFieldOffset(f);
            GeyserBedrockBlock[] old = (GeyserBedrockBlock[]) U.getObject(orig, offset);
            if (old == null) return false;
            GeyserBedrockBlock[] rep = new GeyserBedrockBlock[old.length];
            for (int i = 0; i < old.length; i++) {
                GeyserBedrockBlock b = old[i];
                rep[i] = (b != null && b.getState() != null)
                    ? new GeyserBedrockBlock(BlockHashUtils.fnv1a32Nbt(b.getState()), b.getState())
                    : b;
            }
            U.putObject(orig, offset, rep);
            return true;
        } catch (Throwable e) { return false; }
    }

    /** Replace GeyserSession.upstream with the NetEase-aware forwarding wrapper. */
    public static void install(org.geysermc.geyser.session.GeyserSession session, SpoofedUpstream replacement) throws Throwable {
        Field upF = org.geysermc.geyser.session.GeyserSession.class.getDeclaredField("upstream");
        upF.setAccessible(true);
        long off = U.objectFieldOffset(upF);
        U.putObject(session, off, replacement);
    }

    public static BlockMappings cloneBlockMappings(BlockMappings orig) throws Throwable {
        BlockMappings copy = (BlockMappings) U.allocateInstance(BlockMappings.class);
        for (Field f : BlockMappings.class.getDeclaredFields()) {
            long off = U.objectFieldOffset(f);
            U.putObject(copy, off, U.getObject(orig, off));
        }
        for (String name : new String[]{"javaToBedrockBlocks", "bedrockRuntimeMap", "javaToVanillaBedrockBlocks"}) {
            Field f = BlockMappings.class.getDeclaredField(name);
            long off = U.objectFieldOffset(f);
            Object[] arr = (Object[]) U.getObject(orig, off);
            if (arr != null) U.putObject(copy, off, arr.clone());
        }
        return copy;
    }
}
