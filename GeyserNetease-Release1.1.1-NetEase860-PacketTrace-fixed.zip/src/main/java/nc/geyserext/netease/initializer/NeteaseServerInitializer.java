package nc.geyserext.netease.initializer;

import nc.geyserext.netease.NeteaseExtension;
import nc.geyserext.netease.handler.NetEaseUpstreamHandler;
import nc.geyserext.netease.handler.UpstreamHandlerBase;
import io.netty.channel.Channel;
import org.cloudburstmc.netty.channel.raknet.config.RakChannelOption;
import org.cloudburstmc.protocol.bedrock.BedrockServerSession;
import org.cloudburstmc.protocol.bedrock.netty.codec.compression.*;
import org.cloudburstmc.protocol.bedrock.netty.codec.packet.BedrockPacketCodec;
import org.cloudburstmc.protocol.bedrock.netty.codec.packet.BedrockPacketCodec_v3;
import org.geysermc.geyser.GeyserImpl;
import org.geysermc.geyser.network.GeyserServerInitializer;
import org.geysermc.geyser.session.GeyserSession;
import io.netty.channel.EventLoopGroup;
import org.checkerframework.checker.nullness.qual.NonNull;

public class NeteaseServerInitializer extends GeyserServerInitializer {
    private static final int NETEASE_RAKNET = 8;
    private final boolean rakCookie;
    private final boolean onlyNeteaseClients;

    public NeteaseServerInitializer(GeyserImpl geyser, boolean rakCookie, boolean onlyNeteaseClients) {
        super(geyser, "Geyser player thread");
        this.rakCookie = rakCookie;
        this.onlyNeteaseClients = onlyNeteaseClients;
    }

    @Override
    protected void preInitChannel(Channel c) throws Exception {
        if (!rakCookie) c.setOption(RakChannelOption.RAK_PROTOCOL_VERSION, 11);
        super.preInitChannel(c);
        int rakVer = c.config().getOption(RakChannelOption.RAK_PROTOCOL_VERSION);
        if (rakVer == NETEASE_RAKNET) {
            c.pipeline().replace(CompressionCodec.NAME, CompressionCodec.NAME,
                new CompressionCodec(new SimpleCompressionStrategy(new NoopCompression()), false));
        }
    }

    @Override
    protected void initPacketCodec(Channel c) throws Exception {
        int rakVer = c.config().getOption(RakChannelOption.RAK_PROTOCOL_VERSION);
        if (rakVer == NETEASE_RAKNET) {
            c.pipeline().addLast(BedrockPacketCodec.NAME, new BedrockPacketCodec_v3());
            return;
        }
        super.initPacketCodec(c);
    }


    /**
     * Compatibility accessor for the official Geyser core's player event-loop group.
     * Session construction itself uses the connected channel's event loop.
     */
    public EventLoopGroup playerEventLoopGroup() {
        try {
            java.lang.reflect.Field field = GeyserServerInitializer.class.getDeclaredField("eventLoopGroup");
            field.setAccessible(true);
            return (EventLoopGroup) field.get(this);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Unable to access Geyser player event loop group", e);
        }
    }

    @Override
    public void initSession(@NonNull BedrockServerSession srv) {
        try {
            srv.setLogging(geyser.config().debugMode());
            GeyserSession session = new GeyserSession(geyser, srv, srv.getPeer().getChannel().eventLoop());
            if (!srv.isSubClient()) {
                try {
                    srv.getPeer().getChannel().pipeline().addAfter(BedrockPacketCodec.NAME,
                        org.geysermc.geyser.network.bedrock.InvalidPacketHandler.NAME,
                        new org.geysermc.geyser.network.bedrock.InvalidPacketHandler(session));
                } catch (Exception ignored) {}
            }
            int rakVer = srv.getPeer().getChannel().config().getOption(RakChannelOption.RAK_PROTOCOL_VERSION);
            if (rakVer == NETEASE_RAKNET) {
                srv.setPacketHandler(new NetEaseUpstreamHandler(geyser, session));
            } else {
                if (onlyNeteaseClients) {
                    session.disconnect(NeteaseExtension.CONFIG.disconnectMessage());
                    return;
                }
                srv.setPacketHandler(new UpstreamHandlerBase(geyser, session));
            }
        } catch (Throwable e) {
            geyser.getLogger().error("Error initializing player!", e);
            srv.disconnect(e.getMessage());
        }
    }
}
